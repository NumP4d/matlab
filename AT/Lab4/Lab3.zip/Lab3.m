clear;
close all;
clc;

T_sim   = 20;
Tchange = 20;
%Tchange = 1.8;

% Controller timing parameters
Tc              = 0.1;
time_controller = 0:Tc:T_sim;
N_sampling      = 100;
% Simulation timing parameters
Ts      = Tc / N_sampling;
time    = 0:Ts:T_sim;

% Initial conditions
xi = [  0;
        0];
ui =    0;
y0 =    0;

% ARX model setting
nB = 1;
nA = 2;
delModel = 1;

% Initial for RLS algorithm
%bi = zeros(delModel + nB + nA, 1);
bi = [0.007136; 0.006788; -1.856; 0.8607];
Pi = diag(0.1 * ones(length(bi), 1));
disp(Pi)

% Storage vectors
x = xi;
u = ui;
y = y0;
% Prediction of output
y_p = y0;
% Controller viewable y
y_c = y0;

% 2nd order inertia
k  = 3;
T1 = 1;
T2 = 2;
Delay = 0;
[A, B, C, D] = TranslateModel(k, T1, T2);

% Controller setup
sum_e       = 0;
SP          = 7;
kcontrol    = 0.8;
Ticontrol   = 3;

for i = 1:(length(time_controller)-1)
    % After steady state update model parameters
    if (time_controller(i) >= Tchange)
        %kn = k * 25;
        %kn = k * 3 * (1 + sin(time_controller(i) * 5));
        kn = k;
        %Delay = Delay * (1 + sin(time_controller(i) * 5));
        %kn = k;
        T1n = T1;
        T2n = T2;
        SP = 14;
        %T2n = T2 * 0.01;
        %T1n = T1 * 3;
        %T2n = T2 * 2;
        [A, B, C, D] = TranslateModel(kn, T1n, T2n);
    end
    
    % Generate fi vector
    [fi] = GenerateFi(u, y_c, delModel, nB, nA);
    
    y_pi = ModelPlant(fi, bi);
    
    for j = 1:N_sampling
        [xi, yi] = Plant(xi, u, A, B, C, D, Delay, Ts, Tc);
        % Save plant state and output
        x = [x, xi];
        y = [y, yi];
    end
    y_c = [y_c, yi];
    ui = 1;
    % Save controller state
    u = [u, ui];
    [bi, Pi] = RLS_Plant(fi, yi, bi, Pi);
    % Save prediction
    y_p = [y_p, y_pi];
    %[ui, sum_e] = Controller(SP, yi, sum_e, kcontrol, Ticontrol, Tc);
    %[ui, sum_e, kcontrol] = AdaptiveController(SP, yi, sum_e, kcontrol, Ticontrol, Tc);
end

% Plot results
figure;
subplot(2, 1, 1);
plot(time, y());
grid on;
hold on;
plot(time_controller, y_p);
subplot(2, 1, 2);
plot(time_controller, u);
grid on;