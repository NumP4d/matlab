function [bi_n, Pi_n] = RLS_Plant(fi, yi, bi, Pi)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
    Pi_n = Pi - (Pi * fi + fi' * Pi) / (1 + fi' * Pi * fi);
    ki_n = Pi_n * fi;
    bi_n = bi + ki_n * (yi - fi' * bi);
end

