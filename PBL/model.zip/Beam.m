function [Fni] = Beam(Fni, xi, phase)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

    % Scale from meters to milimeters
    %xi = xi * 10^(3);
    
    if (xi < 0)
        xi = 0;
    end

    switch(phase)
        case 1
            Fni = 37.973 * xi;
        case 2
            Fni = 19.029 * xi + 21.296;
        case 3
            Fni = 13.841 * xi + 50.869;
        case 4
            Fni = -5.9 * xi + 220.96; 
        case 5
            Fni = -73.267 * xi + 832.8;
    end
    
    % Saturation below 0
    if (Fni < 0)
        Fni = 0;
    end
end

