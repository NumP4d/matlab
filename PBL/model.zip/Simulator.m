clear;
close all;
clc;

% Simulation time
T_sim   = 2000;

% Controller timing parameters
Tc              = 2;
time_controller = 0:Tc:T_sim;
N_sampling      = 100;
% Simulation timing parameters
Ts      = Tc / N_sampling;
time    = 0:Ts:T_sim;
% Beam phase update time
T_beam    = 5;
time_beam = 0:T_beam:T_sim;

% Initial conditions
Pi = 0;
xi = 0;
ui = 0;
dxi = 0;

Vs = 0;

% Damper
Pxi = 0.001;    % to prevent NaNs
Vti = 0;
yi = 0;

Fni = 0;
Fti = 0;

xryg = 0;
phase_constr = 1;

% Beam not used before
phasei = 1;

% Storage vectors
P = Pi;
x = xi;
u = ui;
Fn = Fni;
phase = phasei;

for i = 1:(length(time_controller)-1)
    
    for j = 1:N_sampling
        [Fni, phase_constr, xryg, xi_beam] = Construction(Fni, xi, xryg, phase_constr);
        Fni = Beam(Fni, xi_beam, phasei);    % Uncomment this to enable beam connection
        Fti = Resistance(dxi);
        [Pxi, Vti, yi] = Damper(Pxi, Pi, yi, Ts);
        [xi, dxi, Vs] = Actuator(xi, Pi, Fti, Fni, Ts);
        Pi = ControlValve(Pi, ui, Vs, Vti, Ts);

        % Save plant states and outputs
        P = [P, Pi];
        x = [x, xi];
        Fn = [Fn, Fni];
    end
    
    % Beam phase update
    if (mod(i, round(T_beam / Tc)) == 0)
        phasei = BeamPhase(Fni, phasei);
        phase = [phase, phasei];
    end
    
    % Set step responses 0:10:100
    if (mod(i, round((length(time_controller)-1) / 11)) == 0)
        ui = ui + 10;
    end

   % ui = 100;
    
    % Save u
    u = [u, ui];
    
end

figure;
subplot(3, 1, 1);
plot(time, P);
ylabel('P, MPa');
subplot(3, 1, 2);
stairs(time_controller, u);
ylabel('u, %');
subplot(3, 1, 3);
plot(time, x * 10^(3));
hold on;
plot(time, x * 0 + xryg, 'k--');
plot(time, x * 0 + xryg + 6, 'k--');
ylabel('x, mm');

xlabel('time, s');

figure;
subplot(2, 1, 1);
plot(time, Fn);
subplot(2, 1, 2);
plot(phase);